@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Installer.ps1" -Uninstall
